// import React, { useEffect, useState } from 'react';
// import { useLocation } from 'react-router-dom';

// export default function VerifyEmailPage() {
//   const [message, setMessage] = useState('Verifying...');
//   const location = useLocation();

//   useEffect(() => {
//     const query = new URLSearchParams(location.search);
//     const token = query.get('token');

//     if (!token) {
//       setMessage('Invalid verification link');
//       return;
//     }

//     fetch(`http://localhost:5000/verify-email?token=${token}`)
//       .then((res) => res.text())
//       .then((text) => setMessage(text))
//       .catch(() => setMessage('Verification failed'));
//   }, [location]);

//   return (
//     <div>
//       <h2>Email Verification</h2>
//       <p>{message}</p>
//     </div>
//   );
// }


import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

export default function VerifyEmailPage() {
  const [message, setMessage] = useState('Verifying...');
const { token } = useParams(); 
  // useEffect(() => {
  //   if (!token) {
  //     setMessage('Invalid verification link');
  //     return;
  //   }

    // fetch(`http://localhost:5000/api/auth/verify-email/${token}`)
    //   .then((res) => {
    //     if (!res.ok) throw new Error('Verification failed');
    //     return res.text();
    //   })
    //   .then((text) => setMessage(text))
    //   .catch(() => setMessage('Verification failed'));
    // }, [token]);

     useEffect(() => {
    if (!token) {
      setMessage('Invalid verification link');
      return;
    }

    fetch(`http://localhost:5000/api/verify-email/${token}`)
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setMessage('Email verified successfully!');
        } else {
          setMessage(`Verification failed: ${data.message}`);
        }
      })
      .catch(err => {
        setMessage('An error occurred during verification.');
      });
  }, [token]);


  return (
    <div>
      <h2>Email Verification</h2>
      <p>{message}</p>
    </div>
  );
}
